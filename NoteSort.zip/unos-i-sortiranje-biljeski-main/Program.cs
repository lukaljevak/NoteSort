﻿using System;
using System.Windows.Forms;

namespace NoteSort
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Prikaži formu za login
            LoginForm loginForm = new LoginForm();
            if (loginForm.ShowDialog() == DialogResult.OK) // Provjeri je li prijava uspjela
            {
                // Ako je prijava uspješna, pokreni glavnu formu s prijavljenim korisnikom
                Application.Run(new Notes(loginForm.PrijavljeniKorisnik));
            }
            else
            {
                // Ako korisnik zatvori login formu, zatvori aplikaciju
                Application.Exit();
            }
        }
    }
}