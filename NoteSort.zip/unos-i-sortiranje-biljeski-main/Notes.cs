﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using UnosBiljeski;

namespace NoteSort
{
    public partial class Notes : Form
    {
        private Biljeske biljeske = new Biljeske();
        private string filePath;
        private Korisnik prijavljeniKorisnik;

        // Konstruktor koji prima prijavljenog korisnika
        public Notes(Korisnik korisnik)
        {
            InitializeComponent();
            prijavljeniKorisnik = korisnik;

            // Provjeri i kreiraj direktorij ako ne postoji
            string appDataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NoteSort");
            if (!Directory.Exists(appDataDir))
            {
                Directory.CreateDirectory(appDataDir);
            }

            filePath = Path.Combine(appDataDir, "notes.xml");

            LoadNotes();
            OmoguciFunkcionalnosti();
        }

        private void OmoguciFunkcionalnosti()
        {
            if (prijavljeniKorisnik.Uloga == "Korisnik")
            {
                // Onemogući gumbove za uređivanje i brisanje
                btnEdit.Enabled = false;
                btnDelete.Enabled = false;
                btnNew.Enabled = false;
            }
        }

        private void Notes_Load(object sender, EventArgs e)
        {
            // Postavi DataGridView
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = biljeske.ListaBiljeski;
        }

        private void BtnNew_Click(object sender, EventArgs e)
        {
            UpisBiljeske upisForm = new UpisBiljeske(this);
            upisForm.ShowDialog();
        }

        public void AddNote(string naslov, string opis)
        {
            biljeske.ListaBiljeski.Add(new Biljeska(naslov, opis));
            SaveNotes();
            dataGridView1.DataSource = null; // Osvježi DataGridView
            dataGridView1.DataSource = biljeske.ListaBiljeski;
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                var odabranaBiljeska = (Biljeska)dataGridView1.CurrentRow.DataBoundItem;
                UpisBiljeske upisForm = new UpisBiljeske(this, odabranaBiljeska.Naslov, odabranaBiljeska.Opis, dataGridView1.CurrentRow.Index);
                upisForm.ShowDialog();
            }
        }

        public void UpdateNote(int index, string naslov, string opis)
        {
            biljeske.ListaBiljeski[index].Naslov = naslov;
            biljeske.ListaBiljeski[index].Opis = opis;
            SaveNotes();
            dataGridView1.DataSource = null; // Osvježi DataGridView
            dataGridView1.DataSource = biljeske.ListaBiljeski;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                var result = MessageBox.Show("Jeste li sigurni da želite obrisati ovu bilješku?", "Potvrdi brisanje", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    biljeske.ListaBiljeski.RemoveAt(dataGridView1.CurrentRow.Index);
                    SaveNotes();
                    dataGridView1.DataSource = null; // Osvježi DataGridView
                    dataGridView1.DataSource = biljeske.ListaBiljeski;
                }
            }
        }

        private void SaveNotes()
        {
            biljeske.SpremiUXml(filePath);
        }

        private void LoadNotes()
        {
            try
            {
                if (File.Exists(filePath))
                {
                    biljeske = Biljeske.UcitajIzXml(filePath);
                    dataGridView1.DataSource = biljeske.ListaBiljeski;
                }
                else
                {
                    MessageBox.Show("Datoteka s bilješkama ne postoji. Kreirat će se nova datoteka.", "Informacija", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    biljeske = new Biljeske(); // Kreiraj novu praznu listu bilješki
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri učitavanju bilješki: " + ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
                biljeske = new Biljeske(); // Kreiraj novu praznu listu bilješki u slučaju greške
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            SaveNotes();
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            string filter = txtSearch.Text.ToLower();
            var filtriraneBiljeske = biljeske.ListaBiljeski
                .Where(b => b.Naslov.ToLower().Contains(filter) || b.Opis.ToLower().Contains(filter))
                .ToList();
            dataGridView1.DataSource = filtriraneBiljeske;
        }
    }
}