﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnosBiljeski
{
    public class Korisnik
    {

        public string KorisnickoIme { get; set; }
        public string Lozinka { get; set; }
        public string Uloga { get; set; } 

        public Korisnik() { }

        public Korisnik(string korisnickoIme, string lozinka, string uloga)
        {
            KorisnickoIme = korisnickoIme;
            Lozinka = lozinka;
            Uloga = uloga;
        }
    }
}
