﻿namespace NoteSort
{
    public class Biljeska
    {
        public string Naslov { get; set; }
        public string Opis { get; set; }

        public Biljeska() { }

        public Biljeska(string naslov, string opis)
        {
            Naslov = naslov;
            Opis = opis;
        }
    }
}