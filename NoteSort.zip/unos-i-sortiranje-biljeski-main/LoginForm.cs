﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using UnosBiljeski;

namespace NoteSort
{
    public partial class LoginForm : Form
    {
        // Lista korisnika (može se učitati iz baze podataka ili konfiguracijske datoteke)
        private List<Korisnik> korisnici = new List<Korisnik>
        {
            new Korisnik("admin", "admin123", "Administrator"),
            new Korisnik("user", "user123", "Korisnik")
        };

        // Svojstvo za prijavljenog korisnika
        public Korisnik PrijavljeniKorisnik { get; private set; }

        public LoginForm()
        {
            InitializeComponent();
        }

        private void BtnPrijava_Click(object sender, EventArgs e)
        {
            string korisnickoIme = txtKorisnickoIme.Text;
            string lozinka = txtLozinka.Text;

            // Provjeri postoji li korisnik s unesenim podacima
            PrijavljeniKorisnik = korisnici.FirstOrDefault(k => k.KorisnickoIme == korisnickoIme && k.Lozinka == lozinka);

            if (PrijavljeniKorisnik != null)
            {
                this.DialogResult = DialogResult.OK; // Uspješna prijava
                this.Close(); // Zatvori login formu
            }
            else
            {
                MessageBox.Show("Neispravno korisničko ime ili lozinka.", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}